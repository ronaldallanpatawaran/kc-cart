<?php
class ControllerCommonCategory extends Controller {
	public function index() {

	}




}