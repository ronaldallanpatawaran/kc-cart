<?php
class ControllerCommonCommonBanner extends Controller {

	public function index(){
		return $this->load->view('default/template/common/common_banner.tpl');
	}


}
