<?php
// Text
$_['text_information']  = 'Information';
$_['text_service']      = 'Customer Service';
$_['text_extra']        = 'Extras';
$_['text_contact']      = 'Contact Us';
$_['text_return']       = 'Returns';
$_['text_sitemap']      = 'Site Map';
$_['text_manufacturer'] = 'Brands';
$_['text_voucher']      = 'Gift Vouchers';
$_['text_affiliate']    = 'Affiliates';
$_['text_special']      = 'Specials';
$_['text_account']      = 'My Account';
$_['text_order']        = 'Order History';
$_['text_wishlist']     = 'Wish List';
$_['text_newsletter']   = 'Newsletter';
$_['text_fb']           = '<i class="fa fa-facebook"></i>';
$_['text_tw']           = '<i class="fa fa-twitter"></i>';
$_['text_ig']           = '<i class="fa fa-instagram"></i>';
$_['text_powered']      = '&copy; %s %s. All Rights Reserved.';
$_['text_parts_services'] = 'K-C PARTS & SERVICES';
$_['text_product_categories'] = 'PRODUCT CATEGORIES';
$_['text_legalities'] = 'LEGALITIES';
$_['button_contactus'] = 'Contact Us';
$_['button_view_products'] = 'View All Products';