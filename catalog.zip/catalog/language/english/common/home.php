<?php

$_['text_featured_products'] = "Featured Products";
$_['text_parts_services'] = "KC-PARTS & SERVICES";