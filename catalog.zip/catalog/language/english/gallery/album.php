<?php
// Heading
$_['heading_title'] = 'Gallery';

// Text
$_['text_error']    = 'Gallery Page Not Found!';
$_['text_category'] = 'Gallery Categories';
$_['text_album']    = 'Gallery Album';
$_['text_empty']    = 'There are no albums to list in this category.';