<?php
// Heading
$_['heading_title'] = 'Gallery Images';

// Text
$_['text_error']    = 'Gallery Page Not Found!';
$_['text_gallery']  = 'Gallery';
$_['text_category'] = 'Gallery Categories';
$_['text_album']    = 'Gallery Album';