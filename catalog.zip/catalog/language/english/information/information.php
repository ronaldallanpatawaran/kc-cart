<?php
// Text
$_['text_error'] = 'Information Page Not Found!';
$_['text_profile'] = 'PROFILE';
$_['text_history'] = 'HISTORY';
$_['text_mission_and_values'] = "MISSION & VALUES";