<?php
// Heading
$_['heading_title'] = 'Categories';
$_['text_refine']       = 'CATEGORIES';