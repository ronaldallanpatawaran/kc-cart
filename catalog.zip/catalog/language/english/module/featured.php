<?php
// Heading
$_['heading_title'] = 'Featured';
$_['btn_view_details'] = 'View Details';
// Text
$_['text_tax']      = 'Ex Tax:';