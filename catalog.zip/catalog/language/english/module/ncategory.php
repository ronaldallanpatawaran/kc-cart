<?php
// Heading
$_['heading_ncat']     = 'Article Categories';
$_['heading_title']    = 'Articles Menu';
$_['head_search']      = 'Article Search';
$_['artkey']           = 'Keyword';
$_['button_headlines'] = 'Headlines';
?>