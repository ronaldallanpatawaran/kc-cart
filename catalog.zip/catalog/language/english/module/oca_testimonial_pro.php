<?php
// Heading
$_['heading_title'] = 'Testimonial';

// Text
$_['text_tax']      = 'Ex Tax:';

$_['button_next']      = 'Next';
$_['button_prev']      = 'Previous';
$_['button_viewall']      = 'View All';