<?php
// Heading
$_['heading_title']         = 'eNETS Payment (Direct Debit)';

// Text
$_['text_title']            = 'eNETS - Direct Debit/Internet Banking for DBS/POSB/UOB/OCBC/Citibank customers only';
$_['text_payment_failed']   = 'Your payment has failed. No transaction has been made. Please contact the shop administrator for assistance or use a different payment option.';
$_['text_checkout']			= 'Checkout';
?>