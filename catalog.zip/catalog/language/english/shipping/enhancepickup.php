<?php
// Text
$_['text_title']       = 'Pickup From Store';
$_['text_description'] = 'Pickup From Store';
?>